package A;

public enum Type{ //enum constructor with each type
	  DATE, TIME, CURRENCY, DECIMAL, INTEGER, PERCENT
	 }
