package A;

public enum Type { //Types for fields
		DATE, TIME, CURRENCY, DECIMAL, INTEGER, PERCENT, STRING
	}